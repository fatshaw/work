/*
 * main.cpp
 *
 *  Created on: 2010-1-25
 *      Author: root
 */

#include "StreamOperation.h"
#include <cstdlib>
#include "DataPoint.h"
#include "DStream.h"
#include <vector>
#include <ctime>
#include <bitset>
#include "Dbscan.h"
using namespace std;
int roundtime = 1;
typedef hash_map<string, int, str_hash> hashMap;
typedef hash_map<string, int, str_hash>::iterator hashMapIt;
void resultdata(vector<int> &index, vector<DataPoint>&dp, int time, double & ssq, double & purity);

void output(vector<DataPoint>&dp) {
	ofstream out("cluster");
	for (vector<DataPoint>::iterator it = dp.begin(); it != dp.end(); ++it) {
		out << (*it).getLabel() << ", " << (*it).clusterid << endl;
	}
	out.flush();
	out.close();
}

void experimentResult(vector<DataPoint>&dp, int clusterid) {
	ofstream out("experimentdata");
	vector<vector<int> > index;
	for (int i = 0; i < clusterid; ++i) {
		index.push_back(vector<int> ());
	}

	//cout << "clusterid" << clusterid << endl;
	int noise = 0;
	int unclassified = 0;
	for (std::size_t i = 0; i != dp.size(); ++i) {
		if (dp.at(i).clusterid == NOISE)
			++noise;
		else if (dp.at(i).clusterid == UNCLASSIFIED)
			++unclassified;
		else
			index.at(dp.at(i).clusterid).push_back(i);
	}

	double ssq = 0;
	double purity = 0;

	out << "cluster num = " << clusterid << endl;
	out << "noise num = " << noise << endl;
	out << "unclassified num = " << unclassified << endl;
	for (int i = 0; i != clusterid; ++i) {
		resultdata(index.at(i), dp, 0, ssq, purity);
		out << "clusterid = " << i << endl;
		out << "ssq = " << ssq << endl;
		out << "purity" << purity << endl;
	}
	out.flush();
	out.close();
	out.clear();
}

typedef hash_map<string, int, str_hash> pureHash;
typedef hash_map<string, int, str_hash>::iterator pureHashIt;

void resultdata(vector<int> &index, vector<DataPoint>&dp, int time, double & ssq, double & purity) {
	pureHash pure;
	vector<double> sum;
	vector<double> data;
	string label("");
	for (std::size_t i = 0; i < index.size(); ++i) {
		if (dp.at(index.at(i)).getTimeArrive() < time)
			continue;
		label = dp.at(index.at(i)).getLabel();
		if (pure.find(label) == pure.end()) {
			pure[label] = 1;
		} else {
			pure[label]++;
		}
		data = dp.at(index.at(i)).getData();
		if (sum.size() == 0) {
			for (vector<double>::iterator it = data.begin(); it != data.end(); ++it) {
				sum.push_back(*it);
			}
		} else {
			for (std::size_t it = 0; it != data.size(); ++it) {
				sum[it] += data.at(it);
			}
		}
	}

	for (std::size_t i = 0; i != sum.size(); ++i) {
		sum[i] /= index.size();
	}

	ssq = 0;
	double temp = 0;
	for (std::size_t i = 0; i != index.size(); ++i) {
		temp = 0;
		data = dp.at(index.at(i)).getData();
		for (std::size_t j = 0; j != data.size(); ++j) {
			temp += pow(data.at(j) - sum.at(j), 2);
		}
		ssq += temp;
	}

	int max = 0;
	for (pureHashIt it = pure.begin(); it != pure.end(); ++it) {
		if (it->second > max) {
			max = it->second;
		}
	}

	purity = double(max) / index.size() * 100;

}

void svmTest() {
	StreamOperation so;
	std::ifstream input;
	input.open(fileName, ios_base::in);
	vector<string> lines;
	vector<string> items;
	hashMap protocol;
	hashMap service;
	hashMap flags;
	vector<double>itemvalue;
	std::ofstream output;
	output.open("/home/fatshaw/svmtest2");
	int readline = 0;
	int linenum =0;
	int column=0;
	set<string>label;
	vector<vector<double> >dp;
	if (input) {
		readline = so.readStream(input, fileName, lines,1000000);
		for(int i = 0; i< 34 ;++i){
			dp.push_back(vector<double>(readline));
		}
		cout<<"line"<<lines.size()<<endl;
		for (vector<string>::iterator it = lines.begin(); it != lines.end(); ++it) {
			items.clear();
			itemvalue.clear();
			CommonUtil::split(*it, ',', items);
			column = 0;
			for (vector<string>::size_type index = 0; index != items.size(); ++index) {
				//				if (index == PROTOCOL_TYPE) {
				//					if (protocol.find(items.at(index)) == protocol.end()) {
				//						protocol.insert(hashMap::value_type(items.at(index), protocol.size() + 1));
				//					}
				//					temp = protocol[items.at(index)];
				//				} else if (index == SERVICE) {
				//					if (service.find(items.at(index)) == service.end()) {
				//						service.insert(hashMap::value_type(items.at(index), service.size() + 1));
				//					}
				//					temp = service[items.at(index)];
				//				} else if (index == FLAG) {
				//					if (flags.find(items.at(index)) == flags.end()) {
				//						flags.insert(hashMap::value_type(items.at(index), flags.size() + 1));
				//					}
				//					temp = flags[items.at(index)];
				//				}
				if(index == PROTOCOL_TYPE || index == SERVICE || index == FLAG)continue;
				if (index != LAND && index != LOGGED_IN && index != IS_HOST_LOGIN && index != IS_GUEST_LOGIN && index != NUM_OUTBOUND_CMDS
						&& index != items.size() - 1 /*&& index != PROTOCOL_TYPE && index != SERVICE && index != FLAG*/) {
					//itemvalue.push_back(atof(items[index].c_str()));
					dp[column++][linenum]=atof(items[index].c_str());
				}
				//				else if(index == DURATION || index == SRC_BYTES || index == DST_BYTES || index == WRONG_FRAGMENT || index == URGENT ||
				//						index == HOT || index == NUM_FAILED_LOGINS || index == NUM_COMPROMISED || index == NUM_ROOT || index == NUM_FILE_CREATIONS
				//						|| index == NUM_SHELLS || index == NUM_ACCESS_FILES || index == COUNT || index == SRV_COUNT || index == DST_HOST_COUNT ||
				//						index == DST_HOST_SRV_COUNT){
				//					temp = atof(items[index].c_str());
				//				}
				else if(index == items.size() - 1){
					if(label.find(items.back())==label.end()){
						label.insert(items.back());
					}
					int result = CommonUtil::findType(items.back());
					//cout<<result<<endl;
					//result = (result ==3?-1: 1);
					dp[column++][linenum]=result;
					//					output<<result<<" ";
					//					for(vector<string>::size_type si = 0 ;si!=itemvalue.size();++si){
					//						output<<si+1<<":"<<double((int)(itemvalue.at(si) * 1000)+0.5)/1000<<" ";
					//					}
					//					output<<endl;
				}
			}
			linenum++;
		}
	}
	cout<<readline<<endl;
	cout<<label.size()<<endl;
	CommonUtil::standardize(dp, 33, readline);
	for(int i = 0;i<readline;++i){
		output<<dp[33][i]<< " ";
		for(int j = 0;j<33;j++){
			output<<j+1<<":"<<dp[j][i]<<" ";
		}
		output<<endl;
	}
	input.close();
	output.flush();
	output.close();
}

void test_p2p(){
	char * fileName = "./bot/p2p";
	StreamOperation so;
	std::ifstream input;
	vector<string> lines;
	vector<string> items;
	vector<string> labelVector;
	vector<DataPoint> dpVector;
	input.open(fileName, ios_base::in);
	vector<double>data;
	clock_t temp = 0;
	int times = 0;
	int lineNum = 0;
	int columnNum = 0;
	int readLineCnt = 0;
	Dstream dstream;
	int readPointNum = 0;
	int timeunit = 6;
	char t[50];
	for (int round = 0; round != readTimes; ++round) {
		lineNum = 0;
		lines.clear();
		readLineCnt = so.readStream(input, fileName, lines, readLine);	
		readPointNum+=readLineCnt;
		for(vector<string>::iterator it = lines.begin();it!=lines.end();++it){
			data.clear();
			columnNum = 0;
			items.clear();
			CommonUtil::split(*it, ',', items);
			if(items.size()==0)break;		
			for(vector<string>::size_type index = 0;index!=items.size()-1;++index){	
				data.push_back(atof(items[index].c_str()));
			}
			total_types[items.back()]+=1;	
			DataPoint dp = DataPoint(data,times++,items.back());
			temp = clock();
			dstream.addPoint(dp);
			total_time += (clock() - temp) / CLOCKS_PER_SEC;
		}
		if (readPointNum == 6000 || readPointNum == 12000 || readPointNum == 18000 || readPointNum == 24000
				|| readPointNum == 30000 || readPointNum == 36000 || readPointNum == 42000 || readPointNum == 48000 ) {
			dstream.experimentResult(total_time);
			memset(t, 50, 0);
			sprintf(t, "cp ./file/experimentdata /home/fatshaw/expdata/expdata%d_%d", timeunit, roundtime);
			system(t);
			timeunit += 6;
		}

		if (readLineCnt < readLine) {/*cout<<"readline < readLine"<<endl;*/
			break;
		}	
	}
	input.close();
	input.clear();
	dstream.experimentResult(total_time);
	memset(t, 50, 0);
	sprintf(t, "cp ./file/experimentdata /home/fatshaw/expdata/expdata%d_%d", timeunit, roundtime);
	system(t);
}

void test() {
	totalNormal = 0;
	totalDos = 0;
	totalR2l = 0;
	totalU2l = 0;
	totalProbing = 0;
	srand((unsigned) time(0));
	double time = 1;
	StreamOperation so;
	std::ifstream input;
	input.open(fileName, ios_base::in);
	//input.open("kddcup.data_10_percent_corrected", ios_base::in);
	vector<string> lines;
	vector<double> data;
	vector<string> items;
	vector<vector<double> > dataVector;
	hashMap protocol;
	hashMap service;
	hashMap flags;
	vector<string> labelVector;
	vector<DataPoint> dpVector;
	Dstream dstream;
	//Dbscan dbscan;
	double temp = 0;
	int lineNum = 0;
	int columnNum = 0;
	int readLineCnt = 0;
	readPointNum = 0;
	//time_t = clock();
	dataVector.clear();
	int timeunit = 2;
	char t[50];
	for (int i = 0; i != DIMENSION; ++i) {
		dataVector.push_back(vector<double> (readLine));
	}

	for (int round = 0; round != readTimes; ++round) {
		//cout << "round = " << round << endl;
		lineNum = 0;
		lines.clear();
		readLineCnt = so.readStream(input, fileName, lines, readLine);
		readPointNum += readLineCnt;
		//	cout << "readLine" << readLineCnt << endl;
		for (vector<string>::iterator it = lines.begin(); it != lines.end(); ++it) {
			columnNum = 0;
			items.clear();
			CommonUtil::split(*it, ',', items);
			if(items.size()==0)break;
			for (vector<string>::size_type index = 0; index != items.size(); ++index) {
				if (index == PROTOCOL_TYPE) {
					if (protocol.find(items.at(index)) == protocol.end()) {
						protocol.insert(hashMap::value_type(items.at(index), protocol.size() + 1));
					}
					temp = protocol[items.at(index)];
				} else if (index == SERVICE) {
					if (service.find(items.at(index)) == service.end()) {
						service.insert(hashMap::value_type(items.at(index), service.size() + 1));
					}
					temp = service[items.at(index)];
				} else if (index == FLAG) {
					if (flags.find(items.at(index)) == flags.end()) {
						flags.insert(hashMap::value_type(items.at(index), flags.size() + 1));
					}
					temp = flags[items.at(index)];
					//	temp = log(temp);
				}
				if (index != LAND && index != LOGGED_IN && index != IS_HOST_LOGIN && index != IS_GUEST_LOGIN && index != NUM_OUTBOUND_CMDS
						&& index != items.size() - 1 /*&& index != PROTOCOL_TYPE && index != SERVICE && index != FLAG*/) {
					temp = atof(items[index].c_str());
				}
				//				else if(index == DURATION || index == SRC_BYTES || index == DST_BYTES || index == WRONG_FRAGMENT || index == URGENT ||
				//						index == HOT || index == NUM_FAILED_LOGINS || index == NUM_COMPROMISED || index == NUM_ROOT || index == NUM_FILE_CREATIONS
				//						|| index == NUM_SHELLS || index == NUM_ACCESS_FILES || index == COUNT || index == SRV_COUNT || index == DST_HOST_COUNT ||
				//						index == DST_HOST_SRV_COUNT){
				//					temp = atof(items[index].c_str());
				//				}
				else
					continue;
				dataVector[columnNum++][lineNum] = temp;
			}
			CommonUtil::findType(items.back(), totalDos, totalNormal, totalR2l, totalU2l, totalProbing);
			labelVector.push_back(items.back());
			++lineNum;
		}

		CommonUtil::standardize(dataVector, DIMENSION, readLineCnt);
		for (int lines = 0; lines != readLineCnt; ++lines) {
			data.clear();
			for (int dimension = 0; dimension != DIMENSION; ++dimension) {
				//				if (dimension == PROTOCOL_TYPE) {
				//					double temp = dataVector[dimension][lines];
				//					bitset<PROTOCOL_TYPE_LENGTH> bit((int) temp);
				//					for (std::size_t bitindex = 0; bitindex != bit.size(); ++bitindex) {
				//						data.push_back(bit[bitindex]);
				//					}
				//				} else if (dimension == SERVICE) {
				//					double temp = dataVector[dimension][lines];
				//					bitset<SERVICE_LENGTH> bit((int) temp);
				//					for (std::size_t bitindex = 0; bitindex != bit.size(); ++bitindex) {
				//						data.push_back(bit[bitindex]);
				//					}
				//				} else if (dimension == FLAG) {
				//					double temp = dataVector[dimension][lines];
				//					bitset<FLAG_LENGTH> bit((int) temp);
				//					for (std::size_t bitindex = 0; bitindex != bit.size(); ++bitindex) {
				//						data.push_back(bit[bitindex]);
				//					}
				//				} else {
				//					data.push_back(dataVector[dimension][lines]);
				//				}
				data.push_back(dataVector[dimension][lines]);
			}
			dpVector.push_back(DataPoint(data, time++, labelVector.at(lines)));
			if (readLineCnt < readLine)
				break;
		}
		clock_t temp = clock();
		for (vector<DataPoint>::iterator it = dpVector.begin(); it != dpVector.end(); ++it) {
			dstream.addPoint(*it);
		}
		total_time += (clock() - temp) / CLOCKS_PER_SEC;
		labelVector.clear();
		dpVector.clear();
		if (readPointNum == 20000 || readPointNum == 60000 || readPointNum == 100000 || readPointNum == 140000 || readPointNum == 180000
				|| readPointNum == 220000 || readPointNum == 260000 || readPointNum == 300000 || readPointNum == 340000 || readPointNum
				== 380000 || readPointNum == 420000 || readPointNum == 460000) {
			dstream.experimentResult(total_time);
			memset(t, 50, 0);
			sprintf(t, "cp ./file/experimentdata /home/fatshaw/expdata/expdata%d_%d", timeunit, roundtime);
			system(t);
			timeunit += 4;
		}

		if (readLineCnt < readLine) {/*cout<<"readline < readLine"<<endl;*/
			break;
		}
	}

	//	ofstream out("distance2");
	//
	//	for(vector<DataPoint>::iterator it = dpVector.begin();it != dpVector.end();++it){
	//		out<<*it<<endl;
	//	}

	//dbscan.build(dpVector);
	//output(dpVector);
	//experimentResult(dpVector,dbscan.clusterID);
	//dpVector.clear();
	input.close();
	input.clear();
	//time_t = (clock() - time_t) / CLOCKS_PER_SEC;
	dstream.experimentResult(total_time);
	memset(t, 50, 0);
	sprintf(t, "cp ./file/experimentdata /home/fatshaw/expdata/expdata%d_%d", timeunit, roundtime);
	system(t);
}

class Test {
	public:
		int a;
		int b;
		Test() {
			a = 10;
			b = 10;
		}
		~Test() {
			//cout << "destroy" << endl;
			//	cout << "a = " << a << "b = " << b << endl;
		}
		Test(const Test & t) {
			cout << "copy" << endl;
			a = t.a;
			b = t.b;
			cout << "a = " << a << "b = " << b << endl;
		}
};

void init() {
/*	DOS.insert(string("bt"));
	R2L.insert(string("ed"));
	U2L.insert(string("skype"));
	U2L.insert(string("maze"));
	R2L.insert(string("pptv"));
	PROBING.insert(string("peacomm"));	*/

	types_no.insert(make_pair(S_BT,BT));
	types_no.insert(make_pair(S_ED,ED));
	types_no.insert(make_pair(S_MAZE,MAZE));
	types_no.insert(make_pair(S_SKYPE,SKYPE));
	types_no.insert(make_pair(S_PPTV,PPTV));
	types_no.insert(make_pair(S_PEACOMM,PEACOMM));
	
	types.push_back(S_BT);
	types.push_back(S_ED);
	types.push_back(S_MAZE);
	types.push_back(S_SKYPE);
	types.push_back(S_PPTV);
	types.push_back(S_PEACOMM);
}

void m(void ** a) {
	*a = malloc(10);
	memset(*a, 0, 10 * 4);
	int * b = (int*) *a;
	b[0] = 10;
}

	bool strcmp(char * str1, char * str2) {
		while (*str1 && *str2 && *str1++ == *str2++)
			;
		if (*str1 == '\0' && *str2 == '\0')
			return true;
		else
			return false;
	}

class Id{
	private:
		int a;
	public:
		Id(){}
		Id(int i){
			a = i;
		}
};

class Test1{
	private:
		Id i;
		char name[20];
	public:
		Test1(int i,char * pname){
			cout<<sizeof(name)<<endl;
			strncpy(name,pname,sizeof(pname));
			cout<<sizeof(name)<<endl;
			cout<<name<<endl;
			if(name[sizeof(name)-1]=='\0'){
				cout<<"adf"<<endl;
			}
		}
};

int main(int argc,char ** argv) {
	init();
	/*
	   vector<int> gaps;
	   gaps.push_back(10000);
	   gaps.push_back(5000);
	   vector<int> len;
	   len.push_back(25);
	   len.push_back(20);
	   for (vector<int>::iterator git = gaps.begin(); git != gaps.end(); ++git) {
	   gap = *git;
	   if(gap == 5000)beta = 2;
	   for (vector<int>::iterator it = len.begin(); it != len.end(); ++it) {
	   globalWarp = *it;
//for (vector<int>::iterator sit = speed.begin(); sit != speed.end(); ++sit) {
// = *sit;
//for(int lines = 10000;lines<=500000;lines+=40000){
//readTimes = 500000 / readLine;
//time_t = clock();
test();
++roundtime;
//time_t = (clock() - time_t) / CLOCKS_PER_SEC;
//memset(t, 50, 0);
//sprintf(t, "cp ./file/experimentdata /root/expdata/expdata%d", i++);
//system( t);
//}
//}
}
}
	 */

//test();
test_p2p();
//svmTest();
/*int op = 0;
  extern char *optarg;
  while((op = getopt(argc,argv,"T:t:L:l:f:c:")) != EOF){
  switch(op){
  case 'T':
  cout<<optarg;
  break;
  case 't':
  cout<<optarg;
  break;
  case 'L':
  cout<<atoi(optarg);
  break;
  case 'l':
  cout<<atoi(optarg);
  break;
  case 'f':
  cout<<atoi(optarg);
  break;
  case 'c':
  cout<<atoi(optarg);
  break;
  }
  }
 */
cout << "end" << endl;
//	int * a = 0;
//	m((void**)&a);
//	cout<<*a<<endl;
//char * str1 ="abc22";
//char * str2 ="abc22";
//bool result = strcmp(str1,str2);
//if(result == true){
//	cout<<"true"<<endl;
//}else{
//	cout<<"flase";
//}
//	Dstream ds;
//	ds.cudaLocalBuildCluster();

#ifdef WIN32
system("pause");
#endif
return 0;
}

