Easwy's Share
=============

This repository contains vim configurations of Easwy Yang.

Contents
---------

* [.vimrc] --- Easwy's .vimrc
* [.gvimrc] --- Easwy's .gvimrc
* [.vim] --- Easwy's .vim directory

Contact Me
----------

You can contact me by leave a comment on [Easwy's Blog](http://easwy.com/)

