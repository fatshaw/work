Easwy's Share
=============

This repository contains many files shared by Easwy Yang.

Contents
---------

* [conf] --- some configuration files Easwy used
* [scripts] --- some scripts Easwy used
* [vim] --- contain files about vim, such as vimrc and .vim directory

Contact Me
----------

You can contact me by leave a comment on [Easwy's Blog](http://easwy.com/)

