#/bin/sh 
if [ ! $# -eq 1 ];then
	echo "usage sh parser.sh paramsfilename"
	exit
fi

set -x

render()
{
	FILE=$1
	PARAM=$2

	while read line
	do
		key=`echo $line | awk -F '=' '{print $1}'`;
		value=`echo $line | awk -F '=' '{print $2}'`
		sed -i "s/$"{"${key}"}"/$value/g" $FILE
	done < $PARAM
}

FILE="$1"
while read -r line ;
do
	if [[ "$line" =~ \[([0-9a-zA-Z./-]*)\] ]] ; 
	then
		LHS=${BASH_REMATCH[1]}
		OUTPUT_FILE=$LHS
	elif [[  "$line" =~ @base=(.*) ]] ;
	then
		LHS=${BASH_REMATCH[1]}
		BASE_FILE=$LHS
		render $OUTPUT_FILE $BASE_FILE
	elif [[  "$line" =~ @tpl=(.*) ]] ; 
	then
		LHS=${BASH_REMATCH[1]}
		TPL_FILE=$LHS
		cp $TPL_FILE $OUTPUT_FILE
	elif [[ "$line" =~ @param=(.*) ]]; 
	then
		LHS=${BASH_REMATCH[1]}
		PARAM_FILE=$LHS
		render $OUTPUT_FILE $PARAM_FILE
	fi

done < $FILE 

set +x



