#/bin/sh 
set -x

replace_kv()
{
	FILE=$1
	LINE=$2
	key=`echo $LINE | awk -F '=' '{print $1}'`;
	value=`echo $LINE | awk -F '=' '{print $2}'`
	sed -i "s/$"{"${key}"}"/$value/g" $FILE
}

render_file()
{
	FILE=$1
	PARAM=$2

	while read LINE
	do
		replace_kv $FILE $LINE
	done < $PARAM
}

create_dir()
{
	LINE=$1
	DIR=`echo $LINE | awk -F '/' '{print $1}'`
	mkdir -p $DIR
}

render()
{
	FILE="$1"
	DIR_PREFIX=`dirname $FILE`
	while read LINE;
	do
		if [[ "$LINE" =~ \[([0-9a-zA-Z./-]*)\] ]] ; 
		then
			LHS=${BASH_REMATCH[1]}
			OUTPUT_FILE=$DIR_PREFIX/$LHS
			mkdir -p `dirname $OUTPUT_FILE`
		elif [[  "$LINE" =~ @base=(.*) ]] ;
		then
			LHS=${BASH_REMATCH[1]}
			BASE_FILE=$LHS
			render_file $OUTPUT_FILE $BASE_FILE
		elif [[  "$LINE" =~ @tpl=(.*) ]] ; 
		then
			LHS=${BASH_REMATCH[1]}
			TPL_FILE=$LHS
			cp $TPL_FILE $OUTPUT_FILE
		else 
			replace_kv $OUTPUT_FILE $LINE
		fi
	done < $FILE
}

loop_dir()
{
	for NAME in `ls -d $1/[a-z]*`
	do
		if [ -d $NAME ];then 
			NAME=`basename $NAME`;
			loop_dir "$1/$NAME"
		elif [[ "$NAME" =~ .*/params ]];
		then
			render $NAME
		fi
	done
}

loop_dir .

set +x

